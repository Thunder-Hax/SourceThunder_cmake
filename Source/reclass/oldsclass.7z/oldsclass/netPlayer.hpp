#pragma once
#include "..\stdafx.h"
#include "netPlayerData.hpp"

//namespace rage
//{
//    class netPlayer
//    {
//    public:
//		virtual ~netPlayer() = default;
//		virtual void reset() = 0;
//		virtual bool is_valid() = 0;
//		virtual const char* get_name() = 0;
//		virtual void _0x20() = 0;
//		virtual bool is_host() = 0;
//		virtual netPlayerData* get_net_data() = 0;
//		virtual void _0x38() = 0;
//    }; //Size: 0x0008
//    //static_assert(sizeof(netPlayer) == 0x8);
//}
