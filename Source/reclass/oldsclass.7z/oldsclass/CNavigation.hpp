#pragma once
#include "..\stdafx.h"
#include "vector.hpp"

//class CNavigation
//{
//public:
//	char pad_0000[32]; //0x0000
//	float m_heading; //0x0020
//	float m_heading2; //0x0024
//	char pad_0028[8]; //0x0028
//	rage::fvector3 m_rotation; //0x0030
//	char pad_003C[20]; //0x003C
//	rage::fvector3 m_position; //0x0054
//}; //Size: 0x0060
//static_assert(sizeof(CNavigation) == 0x5C);
//class CNavigation
//{
//public:
//    char pad_0000[32]; //0x0000
//    rage::fvector3 m_right; //0x0020
//    char pad_002C[4]; //0x002C
//    rage::fvector3 m_forward; //0x0030
//    char pad_003C[4]; //0x003C
//    rage::fvector3 m_up; //0x0040
//    char pad_004C[4]; //0x004C
//    rage::fvector3 m_position; //0x0050
//}; //Size: 0x0060


//class datBase2
//{
//public:
//	virtual ~datBase2() = default;
//};
//
//class pgBase
//{
//public:
//	virtual ~pgBase() = default;
//private:
//	void* m_pgunk;
//};
//
//class phArchetype
//{
//public:
//	char pad_0000[32]; //0x0000
//	class phBound* m_bound; //0x0020
//	char pad_0028[16]; //0x0028
//}; //Size: 0x0038
////static_assert(sizeof(phArchetype) == 0x38);
//
//class phArchetypePhys : public phArchetype
//{
//public:
//	char pad_0038[28]; //0x0028
//	float m_water_collision; //0x0054
//	char pad_0058[40]; //0x0058
//}; //Size: 0x0080
////static_assert(sizeof(phArchetypePhys) == 0x80);
//
//class phArchetypeDamp : public phArchetypePhys
//{
//public:
//	char pad_0080[96]; //0x0080
//}; //Size: 0x00E0
//static_assert(sizeof(phArchetypeDamp) == 0xE0);
//class phBoundBase : public pgBase
//{
//};
//
//class CNavigation
//{
//public:
//	char pad_0000[16]; //0x0000
//	class phArchetypeDamp* m_damp; //0x0010
//	char pad_0018[8]; //0x0018
//	rage::fvector3 m_right; //0x0020
//	char pad_002C[4]; //0x002C
//	rage::fvector3 m_forward; //0x0030
//	char pad_003C[4]; //0x003C
//	rage::fvector3 m_up; //0x0040
//	char pad_004C[4]; //0x004C
//	rage::fvector3 m_position; //0x0050
//}; //Size: 0x0060
