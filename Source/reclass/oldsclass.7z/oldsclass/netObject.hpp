#pragma once
#include "..\stdafx.h"
#include "fwEntity.hpp"
#include "../Functions.h"

//class CMoveObjectPooledObject;
//#include <cstdint>
//#include "../Functions.h"
//
//namespace rage
//{
//    template<typename T>
//    union vector2
//    {
//        T data[2];
//        struct { T x, y; };
//    };
//
//    template<typename T>
//    union vector3
//    {
//        T data[3];
//        struct { T x, y, z; };
//    };
//
//    template<typename T>
//    union vector4
//    {
//        T data[4];
//        struct { T x, y, z, w; };
//    };
//
//    template<typename T>
//    union matrix34
//    {
//        T data[3][4];
//        struct { struct { T x, y, z, w; } rows[3]; };
//    };
//
//    template<typename T>
//    union matrix44
//    {
//        T data[4][4];
//        struct { struct { T x, y, z, w; } rows[4]; };
//    };
//
//    typedef vector2<float> fvector2;
//    typedef vector3<float> fvector3;
//    typedef vector4<float> fvector4;
//    typedef matrix34<float> fmatrix34;
//    typedef matrix44<float> fmatrix44;
//}
//
//namespace rage
//{
//    class phArchetype
//    {
//    public:
//        char pad_0000[32]; //0x0000
//        class phBound* m_bound; //0x0020
//        char pad_0028[16]; //0x0028
//    }; //Size: 0x0038
//    //static_assert(sizeof(phArchetype) == 0x38);
//
//    class phArchetypePhys : public phArchetype
//    {
//    public:
//        char pad_0038[28]; //0x0028
//        float m_water_collision; //0x0054
//        char pad_0058[40]; //0x0058
//    }; //Size: 0x0080
//    //static_assert(sizeof(phArchetypePhys) == 0x80);
//
//    class phArchetypeDamp : public phArchetypePhys
//    {
//    public:
//        char pad_0080[96]; //0x0080
//    }; //Size: 0x00E0
//    //static_assert(sizeof(phArchetypeDamp) == 0xE0);
//}
//
//class CNavigation
//{
//public:
//    char pad_0000[16]; //0x0000
//    class rage::phArchetypeDamp* m_damp; //0x0010
//    char pad_0018[8]; //0x0018
//    rage::fmatrix44 m_transformation_matrix;
//
//    rage::fvector3* get_position()
//    {
//        return reinterpret_cast<rage::fvector3*>(&m_transformation_matrix.rows[3]);
//    }
//
//    void model_to_world(const rage::fvector3& model_coords, rage::fvector3& world_coords)
//    {
//        world_coords.x = model_coords.x * m_transformation_matrix.data[0][0] + model_coords.y * m_transformation_matrix.data[1][0] + model_coords.z * m_transformation_matrix.data[2][0] + m_transformation_matrix.data[3][0];
//        world_coords.y = model_coords.x * m_transformation_matrix.data[0][1] + model_coords.y * m_transformation_matrix.data[1][1] + model_coords.z * m_transformation_matrix.data[2][1] + m_transformation_matrix.data[3][1];
//        world_coords.z = model_coords.x * m_transformation_matrix.data[0][2] + model_coords.y * m_transformation_matrix.data[1][2] + model_coords.z * m_transformation_matrix.data[2][2] + m_transformation_matrix.data[3][2];
//    }
//}; //Size: 0x0060
////static_assert(sizeof(CNavigation) == 0x60);
////#pragma pack(pop)
//
//template <typename T>
//class fwRefAwareBaseImpl : public T
//{
//private:
//    void* m_ref; // 0x08
//};
//
//class fwRefAwareBase : public fwRefAwareBaseImpl<datBase>
//{
//};
////static_assert(sizeof(fwRefAwareBase) == 0x10);
//class fwExtension
//{
//public:
//    virtual ~fwExtension() = default;
//    virtual void unk_0x08() = 0;
//    virtual void unk_0x10() = 0;
//    virtual uint32_t get_id() = 0;
//}; //Size: 0x0008
////static_assert(sizeof(fwExtension) == 0x8);
//class fwExtensionContainer
//{
//public:
//    fwExtension* m_entry; //0x0000
//    fwExtensionContainer* m_next; //0x0008
//}; //Size: 0x0010
////static_assert(sizeof(fwExtensionContainer) == 0x10);
//class fwExtensibleBase : public fwRefAwareBase
//{
//public:
//    //virtual bool is_of_type(std::uint32_t hash) = 0;
//    //virtual uint32_t const& get_type() = 0;
//
//    //fwExtensionContainer* m_extension_container; // 0x0010
//    //void* m_extensible_unk; // 0x0018
//
//    //template <typename T>
//    //bool is_of_type()
//    //{
//    //    static auto name = (typeid(T).name()) + 6; // Skip "class "
//    //    static auto name_hash = joaat(name);
//
//    //    return is_of_type(name_hash);
//    //}
//    fwExtensionContainer* m_extension_container; // 0x0010
//    void* m_extensible_unk; // 0x0018
//}; //Size: 0x0020
////static_assert(sizeof(fwExtensibleBase) == 0x20);
//namespace rage
//{
//    class fwDynamicEntityComponent;
//    class crmtRequestPose;
//    class crmtRequestIk;
//    class crFrameFilter;
//    class fwAudEntity;
//    class fwEntity : public fwExtensibleBase
//    {
//    public:
//        /*DEFINE_RAGE_RTTI(rage::fwEntity);*/
//        virtual void* _0x38(void*, void*) = 0;
//        virtual void AddExtension(void* extension) = 0; // 0x40
//        virtual void _0x48() = 0; // not implemented
//        virtual void _0x50() = 0; // only implemented by CEntityBatch
//        virtual void _0x58() = 0;
//        virtual void SetModelInfo(std::uint16_t* model_index) = 0; // 0x60
//        virtual void _0x68(int, fvector4*) = 0;
//        virtual void* _0x70(int) = 0;
//        virtual CNavigation* GetNavigation() = 0; // 0x78
//        virtual CMoveObjectPooledObject* CreateMoveObject() = 0; // 0x80
//        virtual std::uint32_t* GetType() = 0; // 0x88
//        virtual void _0x90() = 0;
//        virtual float _0x98() = 0;
//        //virtual bool TryRequestInverseKinematics(rage::crmtRequestPose* pose, rage::crmtRequestIk* ik) = 0; // 0xA0 implemented only by CPed
//        virtual bool TryRequestFacialAnims(void*) = 0; // 0xA8 implemented only by CPed
//        virtual void* _0xB0() = 0;
//        virtual std::uint8_t _0xB8() = 0; // implemented only by CPed
//        //virtual rage::crFrameFilter* GetFrameFilter() = 0; // 0xC0
//        //virtual rage::fwAudEntity* GetEntityAudio() = 0; // 0xC8
//        virtual void _0xD0() = 0;
//        virtual void SetTransform(fmatrix44* matrix, bool update_pos) = 0; // 0xD8
//        virtual void SetTransform2(fmatrix44* matrix, bool update_pos) = 0; // 0xE0
//        virtual void SetPosition(fvector4* pos, bool update_pos) = 0; // 0xE8
//        virtual void SetHeading(float heading, bool update_pos) = 0; // 0xF0
//        virtual void SetEntityTypeFlags() = 0; // 0xF8
//        virtual void _0x100() = 0; // not implemented
//        virtual void UpdatePhysics(CNavigation* navigation) = 0; // 0x108
//        virtual void UpdatePhysics2(CNavigation* navigation) = 0; // 0x110
//        virtual void UpdatePosition() = 0; // 0x118
//
//        enum class EntityFlags
//        {
//            IS_VISIBLE = (1 << 0)
//        };
//
//        class CBaseModelInfo* m_model_info; //0x0020
//        uint8_t m_entity_type; //0x0028
//        char gap29; //0x0029
//        uint16_t gap2A; //0x002A
//        uint32_t m_flags; //0x002D
//        class CNavigation* m_navigation; //0x0030
//        uint16_t gap38; //0x0038
//        uint16_t gap3A; //0x003A
//        uint32_t gap3C; //0x003C
//        //class rage::fwDynamicEntityComponent* m_dynamic_entity_component; //0x0040 (stores attachments and stuff)
//        //class rage::fwDrawData* m_draw_data; //0x0048
//        //class rage::fwDynamicEntityComponent* gap50; //0x0050
//        uint64_t gap58; //0x0058
//        fmatrix44 m_transformation_matrix; //0x0060
//        //rage::fwEntity* m_render_focus_entity; //0x00A0
//        uint32_t m_render_focus_distance; //0x00A8
//        uint32_t m_flags_2; //0x00AC
//        uint32_t m_shadow_flags; //0x00B0
//        char gapB4[4]; //0x00B4
//        std::uint8_t byteB8; //0x00B8
//
//        fvector3* get_position()
//        {
//            return reinterpret_cast<fvector3*>(&m_transformation_matrix.rows[3]);
//        }
//
//        void model_to_world(const fvector3& model_coords, fvector3& world_coords)
//        {
//            world_coords.x = model_coords.x * m_transformation_matrix.data[0][0] + model_coords.y * m_transformation_matrix.data[1][0] + model_coords.z * m_transformation_matrix.data[2][0] + m_transformation_matrix.data[3][0];
//            world_coords.y = model_coords.x * m_transformation_matrix.data[0][1] + model_coords.y * m_transformation_matrix.data[1][1] + model_coords.z * m_transformation_matrix.data[2][1] + m_transformation_matrix.data[3][1];
//            world_coords.z = model_coords.x * m_transformation_matrix.data[0][2] + model_coords.y * m_transformation_matrix.data[1][2] + model_coords.z * m_transformation_matrix.data[2][2] + m_transformation_matrix.data[3][2];
//        }
//    };
//		//class fwEntity
//		//{
//		//public:
//		//	char pad_0000[32]; //0x0000
//		//	class CBaseModelInfo* m_model_info; //0x0020
//		//	char pad_0028[1]; //0x0028
//		//	int8_t m_entity_type; //0x0029
//		//	char pad_002A[2]; //0x002A
//		//	uint8_t m_invisible; //0x002C
//		//	char pad_002D[3]; //0x002D
//		//	class CNavigation* m_navigation; //0x0030
//		//	char pad_0038[16]; //0x0038
//		//	class rage::fwDrawData* m_draw_data; //0x0048
//		//	char pad_0050[16]; //0x0050
//		//	rage::fvector3 m_right; //0x0060
//		//	char pad_006C[4]; //0x006C
//		//	rage::fvector3 m_forward; //0x0070
//		//	char pad_007C[4]; //0x007C
//		//	rage::fvector3 m_up; //0x0080
//		//	char pad_008C[4]; //0x008C
//		//	rage::fvector3 m_position; //0x0090
//		//	char pad_009C[52]; //0x009C
//		//	class netObject* m_net_object; //0x00D0
//		//	char pad_00D8[176]; //0x00D8
//		//	uint32_t m_damage_bits; //0x0188
//		//}; //Size: 0x018C
//		/*#pragma pack(pop)*/
//    //class netObject
//    //{
//    //public:
//    //    int16_t m_object_type; //0x0008
//    //    int16_t m_object_id; //0x000A
//    //    char pad_000C[61]; //0x000C
//    //    int8_t m_owner_id; //0x0049
//    //    int8_t m_control_id; //0x004A
//    //    int8_t m_next_owner_id; //0x004B
//    //    bool m_is_remote; //0x004C
//    //    bool m_wants_to_delete; //0x004D
//    //    char pad_004E[1]; //0x004E
//    //    bool m_should_not_be_delete; //0x004F
//
//    //    virtual ~netObject();
//    //    virtual void Function1();
//    //    virtual void Function2();
//    //    virtual void Function3();
//    //    virtual void Function4();
//    //    virtual void Function5();
//    //    virtual void Function6();
//    //    virtual void Function7();
//    //    virtual void Function8();
//    //    virtual void Function9();
//    //    virtual void Function10();
//    //    virtual void Function11();
//    //    virtual void Function12();
//    //    virtual void Function13();
//    //    virtual void Function14();
//    //    virtual void Function15();
//    //    virtual void Function16();
//    //    virtual void Function17();
//    //    virtual void Function18();
//    //    virtual void Function19();
//    //    virtual void Function20();
//    //    virtual void Function21();
//    //    virtual void Function22();
//    //    virtual void Function23();
//    //    virtual void Function24();
//    //    virtual void Function25();
//    //    virtual void Function26();
//    //    virtual void Function27();
//    //    virtual void Function28();
//    //    virtual void Function29();
//    //    virtual void Function30();
//    //    virtual void Function31();
//    //    virtual void Function32();
//    //    virtual void Function33();
//    //    virtual void Function34();
//    //    virtual void Function35();
//    //    virtual void Function36();
//    //    virtual void Function37();
//    //    virtual void Function38();
//    //    virtual void Function39();
//    //    virtual void Function40();
//    //    virtual void Function41();
//    //    virtual void Function42();
//    //    virtual void Function43();
//    //    virtual void Function44();
//    //    virtual void Function45();
//    //    virtual void Function46();
//    //    virtual void Function47();
//    //    virtual void Function48();
//    //    virtual void Function49();
//    //    virtual void Function50();
//    //    virtual void Function51();
//    //    virtual void Function52();
//    //    virtual void Function53();
//    //    virtual void Function54();
//    //    virtual void Function55();
//    //    virtual void Function56();
//    //    virtual void Function57();
//    //    virtual void Function58();
//    //    virtual void Function59();
//    //    virtual void Function60();
//    //    virtual void Function61();
//    //    virtual void Function62();
//    //    virtual void Function63();
//    //    virtual void Function64();
//    //    virtual void Function65();
//    //    virtual void Function66();
//    //    virtual void Function67();
//    //    virtual void Function68();
//    //    virtual void Function69();
//    //    virtual void Function70();
//    //    virtual void Function71();
//    //    virtual void Function72();
//    //    virtual void Function73();
//    //    virtual void Function74();
//    //    virtual void Function75();
//    //    virtual void Function76();
//    //    virtual void Function77();
//    //    virtual void Function78();
//    //    virtual void Function79();
//    //    virtual void Function80();
//    //    virtual void Function81();
//    //    virtual void Function82();
//    //    virtual void Function83();
//    //    virtual void Function84();
//    //    virtual void Function85();
//    //    virtual void Function86();
//    //    virtual void Function87();
//    //    virtual void Function88();
//    //    virtual void Function89();
//    //    virtual void Function90();
//    //    virtual void Function91();
//    //    virtual void Function92();
//    //    virtual void Function93();
//    //    virtual void Function94();
//    //    virtual void Function95();
//    //    virtual void Function96();
//    //    virtual void Function97();
//    //    virtual void Function98();
//    //    virtual void Function99();
//    //    virtual void Function100();
//    //    virtual void Function101();
//    //}; //Size: 0x0050
//    //static_assert(sizeof(netObject) == 0x50);
//class netSyncTree
//{
//public:
//	char pad_0000[48]; //0x0000
//	class netSyncTreeNode* m_sync_tree_node; //0x0030
//}; //Size: 0x0038
//
//class netSyncTreeNode
//{
//public:
//	char pad_0000[192]; //0x0000
//	uint32_t m_player_model; //0x00C0
//	uint32_t m_ped_model; //0x00C4
//	uint32_t m_vehicle_model; //0x00C8
//	char pad_00CC[84]; //0x00CC
//	uint32_t m_pickup_model; //0x0120
//	char pad_0124[44]; //0x0124
//	uint32_t m_object_model; //0x0150
//	char pad_0154[692]; //0x0154
//}; //Size: 0x0408
//
////class CObject : public rage::fwEntity
////{
////public:
////}; //Size: 0x018C
//
////#pragma pack(push, 2)
//
////namespace rage
////{
////    class CPhysical
////    {
////    public:
////    };
////}
//}
////namespace rage
////{
//////#pragma pack(push, 1)
////    class CPhysical
////    {
////    public:
////        uint64_t qword2F8;
////        uint64_t qword300;
////        uint32_t dword308;
////    };
//////#pragma pack(pop)
////}
//
//
//
////class netObject
////{
////public:
////	int16_t object_type; //0x0008
////	int16_t object_id; //0x000A
////	char pad_000C[61]; //0x000C
////	int8_t owner_id; //0x0049
////	int8_t control_id; //0x004A
////	int8_t next_owner_id; //0x004B
////	bool is_remote; //0x004C
////	bool wants_to_delete; //0x004D
////	char pad_004E[1]; //0x004E
////	bool should_not_be_deleted; //0x004F
////	char pad_0050[32]; //0x0050
////	uint32_t players_acked; //0x0070
////	char pad_0074[116]; //0x0074
////
////	virtual ~netObject() = 0;
////
////	virtual void m_8() = 0;
////	virtual void m_10() = 0;
////	virtual void m_18() = 0;
////	virtual void* m_20() = 0;
////	virtual void m_28() = 0;
////	virtual netSyncTree* GetSyncTree() = 0;
////	virtual void m_38() = 0;
////	virtual void m_40() = 0;
////	virtual void m_48() = 0;
////	virtual void m_50() = 0;
////	virtual void m_58() = 0;
////	virtual void m_60() = 0;
////	virtual void m_68() = 0;
////	virtual void m_70() = 0;
////	virtual void m_78() = 0;
////	virtual CObject* GetGameObject() = 0;
////	virtual void m_88() = 0;
////	virtual void m_90() = 0;
////	virtual void m_98() = 0;
////	virtual int GetObjectFlags() = 0;
////	virtual void m_A8() = 0;
////	virtual void m_B0() = 0;
////	virtual void m_B8() = 0;
////	virtual void m_C0() = 0;
////	virtual void m_C8() = 0;
////	virtual int GetSyncFrequency() = 0;
////	virtual void m_D8() = 0;
////	virtual void m_E0() = 0;
////	virtual void m_E8() = 0;
////	virtual void m_F0() = 0;
////	virtual void m_F8() = 0;
////	virtual void Update() = 0;
////	virtual bool m_108_1604() = 0; // added in 1604
////	virtual void m_108() = 0;
////	virtual void m_110() = 0;
////	virtual void m_118() = 0;
////	virtual void m_120() = 0;
////	virtual void m_128() = 0;
////	virtual void m_130() = 0;
////	virtual void m_138() = 0;
////	virtual void m_140() = 0;
////	virtual void m_148() = 0;
////	virtual void m_150() = 0;
////	virtual bool m_158(void* player, int type, int* outReason) = 0;
////	virtual void m_160() = 0;
////	virtual bool m_168(int* outReason) = 0;
////	virtual void m_170() = 0;
////	virtual void m_178() = 0;
////	virtual void m_180() = 0;
////	virtual void m_188() = 0;
////	virtual void m_190() = 0;
////	virtual void m_198() = 0;
////	virtual void m_1A0() = 0;
////	virtual void m_1A8() = 0;
////	virtual void m_1B0() = 0;
////	virtual void m_1B8() = 0;
////	virtual void m_1C0() = 0;
////	virtual void m_1C8() = 0;
////	virtual void m_1D0() = 0;
////	virtual void m_1D8() = 0;
////	virtual void m_1E0() = 0;
////	virtual void m_1E8() = 0;
////	virtual void m_1F0() = 0;
////	virtual void m_1F8() = 0;
////	virtual void m_200() = 0;
////	virtual void m_208() = 0;
////	virtual void m_210() = 0;
////	virtual void m_218() = 0;
////	virtual void m_220() = 0;
////	virtual void m_228() = 0;
////	virtual void m_230() = 0;
////	virtual void m_238() = 0;
////	virtual void m_240() = 0;
////	virtual void m_248() = 0;
////	virtual void m_250() = 0;
////	virtual void m_258() = 0;
////	virtual void m_260() = 0;
////	virtual void m_268() = 0;
////	virtual void m_270() = 0;
////	virtual void m_278() = 0;
////	virtual void m_280() = 0;
////	virtual void m_288() = 0;
////	virtual void m_290() = 0;
////	virtual void m_298() = 0;
////	virtual void m_2A0() = 0;
////	virtual void m_2A8() = 0;
////	virtual void m_2B0() = 0;
////	virtual void m_2B8() = 0;
////	virtual void m_2C0() = 0;
////	virtual void m_2C8() = 0;
////	virtual void m_2D0() = 0;
////	virtual void m_2D8() = 0;
////	virtual void m_2E0() = 0;
////	virtual void m_2E8() = 0;
////	virtual void m_2F0() = 0;
////	virtual void m_2F8() = 0;
////	virtual void m_300() = 0;
////	virtual void m_308() = 0;
////	virtual void m_310() = 0;
////	virtual void m_318() = 0;
////	virtual void m_320() = 0;
////	virtual void UpdatePendingVisibilityChanges() = 0;
////};
//
//
//
//
//enum class eModelType : std::uint8_t
//{
//    Invalid,
//    Object,
//    MLO,
//    Time,
//    Weapon,
//    Vehicle,
//    Ped,
//    Destructable,
//    WorldObject = 33,
//    Sprinkler = 35,
//    Unk65 = 65,
//    EmissiveLOD = 67,
//    Plant = 129,
//    LOD = 131,
//    Unk132 = 132,
//    Unk133 = 133,
//    OnlineOnlyPed = 134,
//    Building = 161,
//    Unk193 = 193
//};
//
//
////#pragma pack(push, 2)
////class CBaseModelInfo
////{
////public:
////	char pad_0000[24]; //0x0000
////	uint32_t m_model_hash; //0x0018
////	char pad_001C[129]; //0x001C
////	eModelType m_model_type; //0x009D
////	char pad_009E[6]; //0x009E
////}; //Size: 0x00A4
////static_assert(sizeof(CBaseModelInfo) == 0xA4);
////#pragma pack(pop)
//
////class CBaseModelInfo
////{
////public:
////    char pad_0000[0x18]; //0x0000
////    uint32_t m_model; //0x0018
////    char pad_001C[0x81]; //0x001C
////    BYTE m_model_type; //0x009D
////    char pad_009D[0x2A2]; //0x009E
////    int32_t m_handlingType; //0x0340
////}; //Size: 0x0344
//////#pragma pack(push, 8)
//
//namespace rage {
//    //#pragma pack(push,8)
//    class fwArchetypeDef
//    {
//    public:
//        virtual ~fwArchetypeDef() = 0;
//        virtual int GetTypeIdentifier() = 0;
//
//        float m_lod_dist; //0x0008
//        uint32_t m_flags; //0x000C
//        uint32_t m_special_attribute; //0x0010
//        char pad_0014[12]; //0x0014
//        fvector4 m_bounding_box_min; //0x0020
//        fvector4 m_bounding_box_max; //0x0030
//        fvector4 m_bounding_sphere_center; //0x0040
//        float m_bounding_sphere_radius; //0x0050
//        float m_hd_texture_dist; //0x0054
//        uint32_t m_name_hash; //0x0058
//        uint32_t m_texture_dictionary; //0x005C
//        uint32_t m_clip_dictionary_hash; //0x0060
//        uint32_t m_drawable_dictionary_hash; //0x0064
//        uint32_t m_physics_dictionary_hash; //0x0068
//        enum eAssetType : uint32_t
//        {
//            ASSET_TYPE_UNINITIALIZED = 0,
//            ASSET_TYPE_FRAGMENT = 1,
//            ASSET_TYPE_DRAWABLE = 2,
//            ASSET_TYPE_DRAWABLEDICTIONARY = 3,
//            ASSET_TYPE_ASSETLESS = 4,
//        } m_asset_type; //0x006C
//        uint32_t m_asset_name_hash; //0x0070
//        uint64_t* m_extensions; //0x0078
//        uint16_t unk_0080; //0x0080
//        char pad_0082[12]; //0x0082
//    }; //Size: 0x0090
//    /*static_assert(sizeof(fwArchetypeDef) == 0x90);
//#pragma pack(pop)*/
//}
//
//namespace rage {
//    //#pragma pack(push,8)
//    class fwArchetype : public datBase
//    {
//    public:
//        virtual void Initialize() = 0;
//        virtual void InitializeFromArchetypeDef(uint32_t mapTypeStoreIdx, fwArchetypeDef* archetypeDef, bool) = 0;
//        virtual class fwEntity* CreateEntity() = 0;
//
//        char pad_0008[16]; //0x0008
//        int32_t m_hash; //0x0018
//        char unk_001C[4]; //0x001C
//        fvector3 m_bounding_sphere_center; //0x0020
//        float m_bounding_sphere_radius; //0x002C
//        fvector3 m_aabbMin; //0x0030
//        float m_lod_dist; //0x003C
//        fvector3 m_aabbMax; //0x0040
//        float m_hd_texture_dist; //0x004C
//        uint32_t m_flags; //0x0050
//        char unk_0054[4]; //0x0054
//        uint64_t unk_0058; //0x0058
//        char unk_0060[4]; //0x0060
//        uint32_t m_asset_index; //0x0064
//        uint16_t unk_0068; //0x0068
//        uint16_t unk_006A; //0x006A
//    };
//    /*static_assert(sizeof(fwArchetype) == 0x70);
//#pragma pack(pop)*/
//}
//
//namespace rage
//{
//
//class CBaseModelInfo : public rage::fwArchetype
//{
//public:
//    char pad_0070[8]; //0x0070
//    uint64_t unk_0078; //0x0078
//    uint64_t unk_0080; //0x0080
//    char pad_0088[8]; //0x0088
//    uint64_t unk_0090; //0x0090
//    char pad_0098[5]; //0x0098
//    eModelType m_model_type; //0x009D
//    char pad_009E[6]; //0x009E
//    uint64_t unk_00A8; //0x00A8
//}; //Size: 0x00B0
////static_assert(sizeof(CBaseModelInfo) == 0xB0);
////#pragma pack(pop)
//}
//
