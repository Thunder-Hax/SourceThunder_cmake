#pragma once

namespace lua::command
{
	void bind(sol::state& state);
}