#pragma once

namespace lua::stats
{
	void bind(sol::state& state);
}