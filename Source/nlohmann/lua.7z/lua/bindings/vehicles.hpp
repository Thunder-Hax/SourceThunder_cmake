#pragma once

namespace lua::vehicles
{
	void bind(sol::state& state);
}