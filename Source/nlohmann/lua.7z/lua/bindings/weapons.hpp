#pragma once

namespace lua::weapons
{
	void bind(sol::state& state);
}