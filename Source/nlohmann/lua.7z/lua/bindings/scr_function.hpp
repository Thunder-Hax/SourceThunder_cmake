#pragma once

#include "script_function.hpp"

namespace lua::scr_function
{
	void bind(sol::state& state);
}