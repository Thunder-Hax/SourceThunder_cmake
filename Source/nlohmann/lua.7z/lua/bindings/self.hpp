#pragma once

namespace lua::self
{
	void bind(sol::state& state);
}