#pragma once

namespace lua::event
{
	void bind(sol::state& state);
}