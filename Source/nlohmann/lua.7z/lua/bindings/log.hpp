#pragma once

namespace lua::log
{
	void bind(sol::state& state);
}