#pragma once

namespace lua::global_table
{
	void bind(sol::state& state);
}